(function () {
  const host = window.location.hostname.toLowerCase();

  // =========================================================================
  // PHẦN 1: CHẠY BÊN TRONG IFRAME YOUTUBE (NHẬN LỆNH TĂNG TỐC 16X & TUA)
  // =========================================================================
  if (host.includes("youtube.com") || host.includes("youtube-nocookie.com")) {
    let targetSpeed = null;

    window.addEventListener("message", (e) => {
      if (!e.data || typeof e.data !== "object") return;
      const video = document.querySelector("video");
      if (!video) return;

      if (e.data.action === "K12_SET_SPEED") {
        targetSpeed = e.data.speed;
        video.muted = true;
        video.play().catch(() => {});
        video.playbackRate = targetSpeed;
      } else if (e.data.action === "K12_SKIP_END") {
        video.muted = true;
        if (video.duration && isFinite(video.duration)) {
          video.currentTime = Math.max(0, video.duration - 0.5);
        }
        video.play().catch(() => {});
      }
    });

    setInterval(() => {
      if (targetSpeed !== null) {
        const video = document.querySelector("video");
        if (video && video.playbackRate !== targetSpeed) {
          video.playbackRate = targetSpeed;
        }
      }
    }, 250);

    return;
  }

  // =========================================================================
  // PHẦN 2: CHẠY TRÊN TRANG CHÍNH K12ONLINE.VN
  // =========================================================================
  if (host !== "k12online.vn" && !host.endsWith(".k12online.vn")) {
    return;
  }

  const HIDE_KEY = "k12_ext_hidden";

  function isHidden() {
    return localStorage.getItem(HIDE_KEY) === "1";
  }

  function setHidden(hidden) {
    localStorage.setItem(HIDE_KEY, hidden ? "1" : "0");
    updateVisibilityUI();
  }

  function updateVisibilityUI() {
    const panel = document.getElementById("k12-ext-panel");
    const restoreBtn = document.getElementById("k12-ext-restore");
    const hidden = isHidden();

    if (panel) panel.style.display = hidden ? "none" : "block";
    if (restoreBtn) restoreBtn.style.display = hidden ? "flex" : "none";
  }

  function setStatus(text) {
    const statusEl = document.getElementById("k12-ext-status");
    if (statusEl) statusEl.textContent = text;
  }

  // Hàm click an toàn 100%: gỡ tạm href="javascript:..." để không bao giờ bị lỗi CSP
  // nhưng vẫn kích hoạt đầy đủ cả jQuery lẫn native event listener của trang!
  function triggerClickNoCSP(el) {
    if (!el) return;
    const origHref = el.getAttribute("href");
    if (origHref && origHref.trim().toLowerCase().startsWith("javascript:")) {
      el.removeAttribute("href");
    }
    try {
      el.click();
    } catch (e) {}
    if (window.jQuery) {
      try {
        window.jQuery(el).trigger("click");
      } catch (e) {}
    }
    if (origHref !== null) {
      setTimeout(() => {
        try {
          el.setAttribute("href", origHref);
        } catch (e) {}
      }, 100);
    }
  }

  // -------------------------------------------------------------------------
  // TÍNH NĂNG 1: BYPASS & SKIP VIDEO NGAY LẬP TỨC
  // -------------------------------------------------------------------------
  function bypassAndSkipVideo() {
    setStatus("Đang phá khóa chống tua...");

    try {
      let courseResultId = null;
      let coursewareId = null;
      let lessonId = null;
      let timeComplete = 1500;

      const scripts = document.querySelectorAll("script");
      for (const s of scripts) {
        const text = s.textContent || "";
        if (text.includes("Courseware.Video") && text.includes("courseResultId")) {
          const mRes = text.match(/courseResultId\s*:\s*"([^"]+)"/);
          const mCw = text.match(/coursewareId\s*:\s*"([^"]+)"/);
          const mLes = text.match(/lessonId\s*:\s*"([^"]+)"/);
          const mTime = text.match(/timeComplete\s*:\s*(\d+)/);

          if (mRes) courseResultId = mRes[1];
          if (mCw) coursewareId = mCw[1];
          if (mLes) lessonId = mLes[1];
          if (mTime) timeComplete = parseInt(mTime[1], 10);
        }
      }

      if (window.VHV && window.VHV.App && window.VHV.App.modules) {
        for (const modId in window.VHV.App.modules) {
          const mod = window.VHV.App.modules[modId];
          if (mod && (mod.coursewareType === "Courseware.Video" || mod.videoType || mod.timeComplete !== undefined)) {
            mod.allowSeek = 1;
            mod.viewedTime = (mod.timeComplete || timeComplete) + 10;
            mod.completed = 1;
            if (typeof mod.updateResult === "function") mod.updateResult(true);
            if (typeof mod.saveResult === "function") mod.saveResult(true);
          }
        }
      }

      document.querySelectorAll("video").forEach((v) => {
        v.muted = true;
        if (v.duration) v.currentTime = v.duration - 0.5;
        v.dispatchEvent(new Event("ended", { bubbles: true }));
      });

      document.querySelectorAll("iframe").forEach((ifr) => {
        if (ifr.contentWindow) {
          ifr.contentWindow.postMessage({ action: "K12_SKIP_END" }, "*");
        }
      });

      if (window.videojs) {
        const players = window.videojs.players || (window.videojs.getPlayers && window.videojs.getPlayers()) || {};
        for (const key in players) {
          const player = players[key];
          if (player) {
            try {
              const dur = player.duration() || timeComplete;
              player.currentTime(dur);
              player.trigger("ended");
            } catch (e) {}
          }
        }
      }

      if (window.VHV && typeof window.VHV.Model === "function" && courseResultId) {
        const payload = {
          id: courseResultId,
          courseResultId: courseResultId,
          coursewareId: coursewareId,
          lessonId: lessonId,
          viewedTime: timeComplete + 5,
          timeComplete: timeComplete,
          completed: 1,
          percent: 100
        };
        ["LMS.Learning.CourseResult.Video.edit", "LMS.Learning.CourseResult.edit"].forEach((srv) => {
          try {
            window.VHV.Model(srv)(payload, function () {});
          } catch (e) {}
        });
      }

      setStatus("Đã hoàn thành Video!");
      setTimeout(goNextCourseware, 1200);
    } catch (err) {
      setStatus("Hãy dùng nút Tua 16x!");
    }
  }

  // -------------------------------------------------------------------------
  // TÍNH NĂNG 2: TĂNG TỐC VIDEO 16X
  // -------------------------------------------------------------------------
  function speedUpVideo16x() {
    setStatus("Đang chạy video 16x...");

    if (window.VHV && window.VHV.App && window.VHV.App.modules) {
      for (const modId in window.VHV.App.modules) {
        const mod = window.VHV.App.modules[modId];
        if (mod && mod.allowSeek !== undefined) mod.allowSeek = 1;
      }
    }

    const playBtn = document.querySelector(".vjs-big-play-button, .vjs-play-control.vjs-paused");
    if (playBtn) triggerClickNoCSP(playBtn);

    document.querySelectorAll("video, audio").forEach((v) => {
      v.muted = true;
      v.play().catch(() => {});
      v.playbackRate = 16.0;
    });

    document.querySelectorAll("iframe").forEach((ifr) => {
      if (ifr.contentWindow) {
        ifr.contentWindow.postMessage({ action: "K12_SET_SPEED", speed: 16.0 }, "*");
      }
    });
  }

  // -------------------------------------------------------------------------
  // TÍNH NĂNG 3: TỰ ĐỘNG XEM HẾT FILE PDF / LÝ THUYẾT
  // -------------------------------------------------------------------------
  function autoViewFullFile() {
    setStatus("Đang hoàn thành tài liệu...");

    const understandBtn = document.querySelector(".btn-understand");
    if (understandBtn) {
      if (window.VHV?.App?.modules?.[2]?.markComplete && window.jQuery) {
        window.VHV.App.modules[2].markComplete(window.jQuery(understandBtn));
      } else {
        triggerClickNoCSP(understandBtn);
      }

      setTimeout(() => {
        const confirmBtn = document.querySelector(".lobibox-confirm button.button-confirm-primary, .lobibox-footer .btn-action-primary");
        if (confirmBtn) triggerClickNoCSP(confirmBtn);
      }, 500);
    }

    let pageTimer = setInterval(() => {
      const nextBtn = document.getElementById("next");
      if (nextBtn && !nextBtn.classList.contains("hidden") && nextBtn.style.display !== "none") {
        triggerClickNoCSP(nextBtn);
        setStatus("Đang lật trang PDF...");
      } else {
        clearInterval(pageTimer);
        setStatus("Đã xem hết file!");
        setTimeout(goNextCourseware, 1200);
      }
    }, 600);
  }

  function goNextCourseware() {
    const nextLessonBtn = document.querySelector("a.btn-action-next, a.btn-next");
    if (nextLessonBtn) {
      const href = nextLessonBtn.getAttribute("href");
      if (href && !href.startsWith("javascript:")) {
        window.location.href = href;
      } else {
        triggerClickNoCSP(nextLessonBtn);
      }
    }
  }

  // -------------------------------------------------------------------------
  // TÍNH NĂNG 4: TRÍCH XUẤT ĐÁP ÁN CHUẨN XÁC (HỖ TRỢ BÀI TẬP & ĐỀ THI) & NỘP BÀI
  // -------------------------------------------------------------------------
  function extractJsonArray(str, startPos) {
    let depth = 0;
    let inString = false;
    let escape = false;

    for (let i = startPos; i < str.length; i++) {
      const ch = str[i];
      if (escape) {
        escape = false;
        continue;
      }
      if (ch === "\\") {
        escape = true;
        continue;
      }
      if (ch === '"') {
        inString = !inString;
        continue;
      }
      if (!inString) {
        if (ch === "[") depth++;
        else if (ch === "]") {
          depth--;
          if (depth === 0) {
            return str.slice(startPos, i + 1);
          }
        }
      }
    }
    return null;
  }

  function extractK12ItemsFromScript() {
    // 1. Kiểm tra trong VHV.App.modules trước nếu đã khởi tạo
    if (window.VHV && window.VHV.App && window.VHV.App.modules) {
      for (const modId in window.VHV.App.modules) {
        const mod = window.VHV.App.modules[modId];
        if (mod && Array.isArray(mod.items) && mod.items.length > 0) {
          return mod.items;
        }
      }
    }

    // 2. Quét mọi thẻ <script> và dùng bộ đếm ngoặc vuông để lấy mảng items không rỗng
    const scripts = document.querySelectorAll("script");
    for (const s of scripts) {
      const text = s.textContent || "";
      const regex = /items\s*:\s*\[/g;
      let match;
      while ((match = regex.exec(text)) !== null) {
        const bracketStart = text.indexOf("[", match.index);
        const jsonStr = extractJsonArray(text, bracketStart);
        if (jsonStr && jsonStr.length > 10) {
          try {
            const parsed = JSON.parse(jsonStr);
            if (Array.isArray(parsed) && parsed.length > 0) {
              return parsed;
            }
          } catch (e) {}
        }
      }
    }
    return null;
  }

  function selectK12Input(inputEl) {
    if (!inputEl) return;

    // Click trực tiếp vào input để kích hoạt sự kiện onclick/onchange của K12Online
    if (!inputEl.checked) {
      triggerClickNoCSP(inputEl);
    }
    inputEl.checked = true;
    inputEl.dispatchEvent(new Event("change", { bubbles: true }));

    // Cập nhật giao diện active cho câu Đúng/Sai hoặc Trắc nghiệm
    const label = inputEl.closest("label");
    if (label && !label.classList.contains("active")) {
      triggerClickNoCSP(label);
      label.classList.add("active");
    }
    const radioDiv = inputEl.closest(".radio");
    if (radioDiv && !radioDiv.classList.contains("active")) {
      radioDiv.classList.add("active", "radio-primary");
    }
  }

  function solveAllQuestions() {
    const items = extractK12ItemsFromScript();
    if (!items || items.length === 0) {
      alert("Không tìm thấy dữ liệu đáp án trong trang này!");
      return 0;
    }

    let solvedCount = 0;
    items.forEach((item) => {
      const qId = item.id || item._id;

      if (item.elementType === "Choice") {
        let correctCode = null;
        if (Array.isArray(item.choices)) {
          const correct = item.choices.find((c) => String(c.point) === "1");
          if (correct) correctCode = correct.answerCode;
        } else if (item.choices && typeof item.choices === "object") {
          for (const key in item.choices) {
            if (String(item.choices[key].point) === "1") {
              correctCode = item.choices[key].answerCode;
              break;
            }
          }
        }

        if (correctCode !== null) {
          const input = document.querySelector(
            `input[type="radio"][name="fields[question${qId}]"][value="${correctCode}"], input[type="radio"][id="question${qId}${correctCode}"]`
          );
          if (input) {
            selectK12Input(input);
            solvedCount++;
          }
        }
      } else if (item.elementType === "OnlyTrueFalseFour") {
        const choicesArr = Array.isArray(item.choices)
          ? item.choices
          : Object.values(item.choices || {});

        choicesArr.forEach((c) => {
          // Trong phần Đúng/Sai của K12Online, đáp án lưu ở c.answerTitle ("true"/"false") hoặc c.point
          let val = "false";
          if (c.answerTitle !== undefined && String(c.answerTitle).trim() !== "") {
            const raw = String(c.answerTitle).replace(/<[^>]*>/g, "").trim().toLowerCase();
            if (raw === "true" || raw === "1" || raw === "đúng") val = "true";
            else if (raw === "false" || raw === "0" || raw === "sai") val = "false";
            else val = String(c.point) === "1" ? "true" : "false";
          } else {
            val = String(c.point) === "1" ? "true" : "false";
          }

          const input = document.querySelector(
            `input[type="radio"][name="fields[question${qId}][${c.answerCode}]"][value="${val}"]`
          );
          if (input) {
            selectK12Input(input);
          }
        });
        solvedCount++;
      }
    });

    setStatus(`Đã giải ${solvedCount}/${items.length} câu!`);
    return solvedCount;
  }

  // Hàm tự động bấm nút Nộp bài và chờ xác nhận Modal đến khi thành công
  function autoSubmitExam() {
    setStatus("Đang bấm nút Nộp bài...");

    // Tìm tất cả các nút Nộp bài / Hoàn thành trên cả giao diện Bài tập lẫn Bài thi
    const submitBtn = document.querySelector(
      ".action-submit a.btn-submit, .note-question-bottom a.btn-submit, a.btn-submit, button.btn-submit"
    );

    // Nếu modal xác nhận đã mở sẵn trên màn hình thì bấm xác nhận luôn
    const existingConfirmBtn = document.querySelector(
      ".remodal-is-opened button.remodal-confirm, #remodal-confirm2 button.remodal-confirm, #remodal-confirm1 button.remodal-confirm, .lobibox-confirm button.button-confirm-primary"
    );
    if (existingConfirmBtn && existingConfirmBtn.offsetParent !== null) {
      triggerClickNoCSP(existingConfirmBtn);
      setStatus("Đã xác nhận nộp bài!");
      return;
    }

    if (submitBtn) {
      triggerClickNoCSP(submitBtn);
    }

    // Lặp kiểm tra liên tục trong 4 giây để đợi hộp thoại xác nhận hiện ra và bấm nút "Nộp bài / Đồng ý"
    let attempts = 0;
    const confirmInterval = setInterval(() => {
      attempts++;

      const confirmBtns = document.querySelectorAll(
        "#remodal-confirm2 button.remodal-confirm, " +
        "#remodal-confirm1 button.remodal-confirm, " +
        ".remodal-wrapper.remodal-is-opened button.remodal-confirm, " +
        ".confirm-exam-learning button.remodal-confirm, " +
        ".lobibox-confirm button.button-confirm-primary, " +
        ".lobibox-footer .btn-action-primary, " +
        "button[data-remodal-action='confirm']"
      );

      let clicked = false;
      confirmBtns.forEach((btn) => {
        // Chỉ bấm vào nút xác nhận đang hiển thị thực sự trên màn hình
        const isVisible = btn.offsetWidth > 0 || btn.offsetHeight > 0 || btn.closest(".remodal-is-opened");
        if (isVisible) {
          triggerClickNoCSP(btn);
          clicked = true;
        }
      });

      if (clicked) {
        clearInterval(confirmInterval);
        setStatus("Đã nộp bài thành công!");
      } else if (attempts >= 20) {
        clearInterval(confirmInterval);
        // Nếu sau 4 giây modal không hiện ra, thử gọi hàm submit trực tiếp của module VHV
        try {
          if (window.VHV?.App?.modules?.[2]?.submit) window.VHV.App.modules[2].submit();
          else if (window.VHV?.App?.modules?.[1]?.submit) window.VHV.App.modules[1].submit();
        } catch (e) {}
        setStatus("Đã gửi lệnh nộp bài!");
      }
    }, 200);
  }

  // -------------------------------------------------------------------------
  // GIAO DIỆN BẢNG ĐIỀU KHIỂN NỔI (FLOATING PANEL)
  // -------------------------------------------------------------------------
  function createPanel() {
    if (document.getElementById("k12-ext-panel")) return;

    const panel = document.createElement("div");
    panel.id = "k12-ext-panel";
    panel.style.cssText = `
      position: fixed;
      bottom: 16px;
      right: 16px;
      width: 290px;
      background: #0f172a;
      color: #f8fafc;
      border: 2px solid #38bdf8;
      border-radius: 10px;
      padding: 12px;
      font-family: Arial, sans-serif;
      z-index: 2147483647;
      box-shadow: 0 10px 25px rgba(0,0,0,0.6);
    `;

    panel.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
        <strong style="color:#38bdf8;font-size:13px;">🚀 K12 Bypass Pro</strong>
        <div style="display:flex;gap:6px;align-items:center;">
          <span id="k12-ext-status" style="font-size:11px;background:#1e293b;padding:2px 6px;border-radius:4px;">Sẵn sàng</span>
          <button id="k12-ext-hide" title="Ẩn bảng (Alt+H)" style="background:#334155;color:#cbd5e1;border:none;border-radius:4px;padding:2px 6px;cursor:pointer;font-size:11px;font-weight:bold;">➖ Ẩn</button>
        </div>
      </div>
      <div style="display:flex;flex-direction:column;gap:6px;margin-top:6px;">
        <div style="display:flex;gap:5px;">
          <button id="k12-ext-skip-video" style="flex:1;padding:7px;background:#7c3aed;color:#fff;border:none;border-radius:5px;cursor:pointer;font-weight:bold;font-size:11px;">⏭️ Skip Video</button>
          <button id="k12-ext-speed16" style="flex:1;padding:7px;background:#9333ea;color:#fff;border:none;border-radius:5px;cursor:pointer;font-weight:bold;font-size:11px;">⏩ Tua Nhanh 16x</button>
        </div>
        <button id="k12-ext-view-file" style="width:100%;padding:7px;background:#2563eb;color:#fff;border:none;border-radius:5px;cursor:pointer;font-weight:bold;font-size:11px;">📖 Tự động xem hết file PDF</button>
        <div style="display:flex;gap:5px;">
          <button id="k12-ext-solve" style="flex:1;padding:7px;background:#16a34a;color:#fff;border:none;border-radius:5px;cursor:pointer;font-weight:bold;font-size:11px;">⚡ Tự động làm</button>
          <button id="k12-ext-submit-all" style="flex:1;padding:7px;background:#ea580c;color:#fff;border:none;border-radius:5px;cursor:pointer;font-weight:bold;font-size:11px;">🚀 Làm & Nộp</button>
        </div>
      </div>
    `;

    const restoreBtn = document.createElement("button");
    restoreBtn.id = "k12-ext-restore";
    restoreBtn.title = "Hiện bảng (Alt+H)";
    restoreBtn.textContent = "🛠️";
    restoreBtn.style.cssText = `
      position: fixed;
      bottom: 12px;
      right: 12px;
      width: 34px;
      height: 34px;
      background: rgba(15, 23, 42, 0.95);
      color: #38bdf8;
      border: 1px solid #38bdf8;
      border-radius: 50%;
      cursor: pointer;
      z-index: 2147483647;
      display: none;
      align-items: center;
      justify-content: center;
      font-size: 15px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.4);
    `;

    document.body.appendChild(panel);
    document.body.appendChild(restoreBtn);

    document.getElementById("k12-ext-hide").addEventListener("click", () => setHidden(true));
    restoreBtn.addEventListener("click", () => setHidden(false));

    window.addEventListener("keydown", (e) => {
      if (e.altKey && (e.key === "h" || e.key === "H")) {
        e.preventDefault();
        setHidden(!isHidden());
      }
    });

    document.getElementById("k12-ext-skip-video").addEventListener("click", bypassAndSkipVideo);
    document.getElementById("k12-ext-speed16").addEventListener("click", speedUpVideo16x);
    document.getElementById("k12-ext-view-file").addEventListener("click", autoViewFullFile);
    document.getElementById("k12-ext-solve").addEventListener("click", solveAllQuestions);
    document.getElementById("k12-ext-submit-all").addEventListener("click", () => {
      solveAllQuestions();
      setTimeout(autoSubmitExam, 400);
    });

    updateVisibilityUI();
  }

  setTimeout(createPanel, 1000);
})();